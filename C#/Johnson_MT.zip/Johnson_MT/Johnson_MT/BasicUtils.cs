﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Johnson_MT
{
    class BasicUtils
    {
        // Have yet to create a basic utils class and couldn't find a need for one in this program so try clicking the bottom left of of the screen
        static public void Cool() 
        {
                MessageBox.Show("Wow", "Wow");
        }
    }
}
