﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W4SampleCode
{
    class BasicTools
    {
        public static void Pause()
        {
            Console.WriteLine("\n\nPress any key to Continue\n");
            Console.ReadKey();
        }
    }
}
